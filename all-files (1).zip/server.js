const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 3000);
const DATA_FILE = path.join('/tmp', 'buckity-data.json');
const DEFAULTS = { price_1m: 0.18, price_3m: 0.88, stock_1m: 500, stock_3m: 500 };
let mysqlPool = null;
let localData = { settings: { ...DEFAULTS }, orders: [], keys: [] };

async function initStorage() {
  if (process.env.DATABASE_URL) {
    const mysql = require('mysql2/promise');
    mysqlPool = mysql.createPool(process.env.DATABASE_URL);
    await mysqlPool.execute(`CREATE TABLE IF NOT EXISTS settings (id INT PRIMARY KEY, price_1m DECIMAL(10,2) NOT NULL, price_3m DECIMAL(10,2) NOT NULL, stock_1m INT NOT NULL, stock_3m INT NOT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)`);
    await mysqlPool.execute(`CREATE TABLE IF NOT EXISTS orders (id INT AUTO_INCREMENT PRIMARY KEY, invoice_id VARCHAR(64) UNIQUE NOT NULL, email VARCHAR(254) NOT NULL, duration VARCHAR(8) NOT NULL, quantity INT NOT NULL, amount_usd DECIMAL(10,2) NOT NULL, amount_ltc DECIMAL(18,8) NOT NULL, server_link VARCHAR(255) NOT NULL, tx_hash VARCHAR(128) NOT NULL, payment_status VARCHAR(16) NOT NULL DEFAULT 'Unverified', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
    const [emailColumn]=await mysqlPool.execute("SELECT COUNT(*) AS count FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='email'");
    if(!Number(emailColumn[0].count))await mysqlPool.execute("ALTER TABLE orders ADD COLUMN email VARCHAR(254) NOT NULL DEFAULT '' AFTER invoice_id");
    await mysqlPool.execute(`CREATE TABLE IF NOT EXISTS boost_keys (id INT AUTO_INCREMENT PRIMARY KEY, boost_key VARCHAR(64) UNIQUE NOT NULL, duration VARCHAR(8) NOT NULL, quantity INT NOT NULL, key_status VARCHAR(16) NOT NULL DEFAULT 'Active', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, redeemed_at TIMESTAMP NULL)`);
    await mysqlPool.execute(`INSERT IGNORE INTO settings (id,price_1m,price_3m,stock_1m,stock_3m) VALUES (1,?,?,?,?)`, [DEFAULTS.price_1m, DEFAULTS.price_3m, DEFAULTS.stock_1m, DEFAULTS.stock_3m]);
  } else {
    try { localData = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (_) { saveLocal(); }
  }
}
function saveLocal() { fs.writeFileSync(DATA_FILE, JSON.stringify(localData, null, 2)); }
async function getSettings() {
  if (!mysqlPool) return { ...localData.settings };
  const [rows] = await mysqlPool.execute('SELECT price_1m,price_3m,stock_1m,stock_3m FROM settings WHERE id=1');
  const r = rows[0]; return { price_1m:Number(r.price_1m), price_3m:Number(r.price_3m), stock_1m:Number(r.stock_1m), stock_3m:Number(r.stock_3m) };
}
async function setSettings(next) {
  if (!mysqlPool) { localData.settings = { ...next }; saveLocal(); return; }
  await mysqlPool.execute('UPDATE settings SET price_1m=?,price_3m=?,stock_1m=?,stock_3m=? WHERE id=1',[next.price_1m,next.price_3m,next.stock_1m,next.stock_3m]);
}
async function addOrder(order) {
  if (!mysqlPool) { order.id=(localData.orders.at(-1)?.id||0)+1; localData.orders.push(order); saveLocal(); return order; }
  const [r]=await mysqlPool.execute('INSERT INTO orders (invoice_id,email,duration,quantity,amount_usd,amount_ltc,server_link,tx_hash,payment_status) VALUES (?,?,?,?,?,?,?,?,?)',[order.invoice_id,order.email,order.duration,order.quantity,order.amount_usd,order.amount_ltc,order.server_link,order.tx_hash,order.payment_status]);order.id=r.insertId;return order;
}
async function getOrders() {
  if (!mysqlPool) return [...localData.orders].reverse();
  const [rows]=await mysqlPool.execute('SELECT id,invoice_id,email,duration,quantity,amount_usd,amount_ltc,server_link,tx_hash,payment_status,created_at FROM orders ORDER BY id DESC LIMIT 500');return rows;
}
async function setOrderStatus(id,status) {
  if (!mysqlPool) { const o=localData.orders.find(x=>x.id===id); if(!o)return false;o.payment_status=status;saveLocal();return true; }
  const [r]=await mysqlPool.execute('UPDATE orders SET payment_status=? WHERE id=?',[status,id]);return r.affectedRows>0;
}
async function addKey(item) {
  if (!mysqlPool) { item.id=(localData.keys.at(-1)?.id||0)+1;localData.keys.push(item);saveLocal();return item; }
  const [r]=await mysqlPool.execute('INSERT INTO boost_keys (boost_key,duration,quantity,key_status) VALUES (?,?,?,?)',[item.boost_key,item.duration,item.quantity,item.key_status]);item.id=r.insertId;return item;
}
async function getKeys() {
  if (!mysqlPool) return [...localData.keys].reverse();
  const [rows]=await mysqlPool.execute('SELECT id,boost_key,duration,quantity,key_status,created_at,redeemed_at FROM boost_keys ORDER BY id DESC LIMIT 500');return rows;
}
async function findKey(key) {
  if (!mysqlPool) return localData.keys.find(x=>x.boost_key===key)||null;
  const [rows]=await mysqlPool.execute('SELECT id,boost_key,duration,quantity,key_status,created_at,redeemed_at FROM boost_keys WHERE boost_key=?',[key]);return rows[0]||null;
}
async function redeemKey(key) {
  if (!mysqlPool) { const item=localData.keys.find(x=>x.boost_key===key);if(!item||item.key_status!=='Active')return null;item.key_status='Redeemed';item.redeemed_at=new Date().toISOString();saveLocal();return item; }
  const [r]=await mysqlPool.execute("UPDATE boost_keys SET key_status='Redeemed',redeemed_at=CURRENT_TIMESTAMP WHERE boost_key=? AND key_status='Active'",[key]);return r.affectedRows?findKey(key):null;
}
const ADMIN_USER = 'BUCKITYOWNER2222';
const PASSWORD_RECORD = 'c07c7e3fafb5c6c4026c771fc3057a6c:7b6a48d17e94c63471b5572175165db5270f8c35eb06e56658d9565568b27e4fc672e8111e95ede202dcc4a5c5bf9e040829ba93e067fcc88583a409ff7407e0';
const sessions = new Map();
function passwordMatches(value) {
  const [salt,stored]=PASSWORD_RECORD.split(':');
  const actual=crypto.scryptSync(String(value||''),salt,64);
  const expected=Buffer.from(stored,'hex');
  return actual.length===expected.length && crypto.timingSafeEqual(actual,expected);
}
function parseCookies(req) { return Object.fromEntries(String(req.headers.cookie||'').split(';').filter(Boolean).map(v=>{const i=v.indexOf('=');return [v.slice(0,i).trim(),decodeURIComponent(v.slice(i+1))]})); }
function currentSession(req) {
  const token=parseCookies(req).buckity_session,s=token&&sessions.get(token);
  if(!s||s.expires<Date.now()){if(token)sessions.delete(token);return null}return {token,...s};
}
function requireAdmin(req,res,csrf=false) {
  const s=currentSession(req);if(!s){json(res,401,{error:'Admin login required'});return null}
  if(csrf&&req.headers['x-csrf-token']!==s.csrf){json(res,403,{error:'Invalid security token'});return null}return s;
}
function securityHeaders(res,type='text/html') {
  res.setHeader('Content-Type',type);res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy',"default-src 'self'; connect-src 'self' https://api.coingecko.com; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'");
}
function json(res,status,data){securityHeaders(res,'application/json; charset=utf-8');res.statusCode=status;res.setHeader('Cache-Control','no-store');res.end(JSON.stringify(data));}
function readBody(req){return new Promise((resolve,reject)=>{let b='';req.on('data',c=>{b+=c;if(b.length>50000)reject(new Error('too-large'))});req.on('end',()=>{try{resolve(b?JSON.parse(b):{})}catch(e){reject(new Error('invalid-json'))}});req.on('error',reject)})}
function validDuration(v){return v==='1m'||v==='3m'}
function validQuantity(v){return Number.isInteger(v)&&v>=2&&v<=30&&v%2===0}
function validKey(v){return /^BKT-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(v)}
function validEmail(v){return typeof v==='string'&&v.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)}
const loginAttempts=new Map();
async function api(req,res,url){
  const method=req.method||'GET';
  if(method==='GET'&&url.pathname==='/api/settings') return json(res,200,await getSettings());
  if(method==='POST'&&url.pathname==='/api/orders'){
    const b=await readBody(req),settings=await getSettings();
    const quantity=Number(b.quantity),duration=String(b.duration||''),email=String(b.email||'').trim().toLowerCase(),server=String(b.server_link||'').trim(),tx=String(b.tx_hash||'').trim().toLowerCase(),ltc=Number(b.amount_ltc);
    if(!validDuration(duration)||!validQuantity(quantity)||!validEmail(email)||!/^discord\.gg\/[A-Za-z0-9_-]+$/i.test(server)||!/^[a-f0-9]{64}$/.test(tx)||!Number.isFinite(ltc)||ltc<=0)return json(res,400,{error:'Invalid order details'});
    const orders=await getOrders();if(orders.some(o=>String(o.tx_hash).toLowerCase()===tx))return json(res,409,{error:'This transaction hash is already logged'});
    const invoice_id=String(b.invoice_id||('BKT-'+Date.now())).slice(0,64),amount_usd=Number(((quantity/2)*settings['price_'+duration]).toFixed(2));
    const order={invoice_id,email,duration,quantity,amount_usd,amount_ltc:Number(ltc.toFixed(8)),server_link:server,tx_hash:tx,payment_status:'Unverified',created_at:new Date().toISOString()};
    await addOrder(order);return json(res,201,{ok:true,order});
  }
  if(method==='POST'&&url.pathname==='/api/key/check'){
    const b=await readBody(req),key=String(b.key||'').trim().toUpperCase();if(!validKey(key))return json(res,400,{error:'Invalid key format'});
    const item=await findKey(key);return item?json(res,200,{found:true,key:{boost_key:item.boost_key,duration:item.duration,quantity:Number(item.quantity),key_status:item.key_status,redeemed_at:item.redeemed_at||null}}):json(res,404,{error:'Key not found'});
  }
  if(method==='POST'&&url.pathname==='/api/key/redeem'){
    const b=await readBody(req),key=String(b.key||'').trim().toUpperCase(),server=String(b.server_link||'').trim();if(!validKey(key)||!/^discord\.gg\/[A-Za-z0-9_-]+$/i.test(server))return json(res,400,{error:'Enter a valid key and Discord invite'});
    const item=await findKey(key);if(!item||item.key_status!=='Active')return json(res,409,{error:item?'Key has already been redeemed':'Key not found'});
    const settings=await getSettings(),stockField='stock_'+item.duration;if(settings[stockField]<Number(item.quantity))return json(res,409,{error:'Not enough stock for this key; contact support'});
    const redeemed=await redeemKey(key);settings[stockField]-=Number(item.quantity);await setSettings(settings);return json(res,200,{ok:true,key:redeemed,server_link:server});
  }
  if(method==='POST'&&url.pathname==='/api/admin/login'){
    const ip=req.socket.remoteAddress||'unknown',record=loginAttempts.get(ip)||{count:0,reset:Date.now()+900000};if(Date.now()>record.reset){record.count=0;record.reset=Date.now()+900000}
    if(record.count>=5)return json(res,429,{error:'Too many login attempts. Try again later.'});
    const b=await readBody(req);if(String(b.username)!==ADMIN_USER||!passwordMatches(b.password)){record.count++;loginAttempts.set(ip,record);return json(res,401,{error:'Invalid credentials'})}
    loginAttempts.delete(ip);const token=crypto.randomBytes(32).toString('hex'),csrf=crypto.randomBytes(24).toString('hex');sessions.set(token,{csrf,expires:Date.now()+8*3600000});res.setHeader('Set-Cookie',`buckity_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`);return json(res,200,{ok:true,csrf});
  }
  if(method==='GET'&&url.pathname==='/api/admin/session'){
    const s=currentSession(req);return s?json(res,200,{authenticated:true,csrf:s.csrf}):json(res,200,{authenticated:false});
  }
  if(method==='POST'&&url.pathname==='/api/admin/logout'){
    const s=requireAdmin(req,res,true);if(!s)return;sessions.delete(s.token);res.setHeader('Set-Cookie','buckity_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return json(res,200,{ok:true});
  }
  if(method==='GET'&&url.pathname==='/api/admin/dashboard'){
    if(!requireAdmin(req,res))return;return json(res,200,{settings:await getSettings(),orders:await getOrders(),keys:await getKeys()});
  }
  if(method==='PUT'&&url.pathname==='/api/admin/settings'){
    if(!requireAdmin(req,res,true))return;const b=await readBody(req),next={price_1m:Number(b.price_1m),price_3m:Number(b.price_3m),stock_1m:Number(b.stock_1m),stock_3m:Number(b.stock_3m)};
    if(!Number.isFinite(next.price_1m)||next.price_1m<=0||next.price_1m>100||!Number.isFinite(next.price_3m)||next.price_3m<=0||next.price_3m>100||!Number.isInteger(next.stock_1m)||next.stock_1m<0||!Number.isInteger(next.stock_3m)||next.stock_3m<0)return json(res,400,{error:'Invalid prices or stock values'});
    await setSettings(next);return json(res,200,{ok:true,settings:next});
  }
  const orderMatch=url.pathname.match(/^\/api\/admin\/orders\/(\d+)$/);
  if(method==='PATCH'&&orderMatch){
    if(!requireAdmin(req,res,true))return;const b=await readBody(req),status=String(b.status||'');if(!['Unverified','Paid','Unpaid'].includes(status))return json(res,400,{error:'Invalid status'});
    const id=Number(orderMatch[1]),orders=await getOrders(),order=orders.find(o=>Number(o.id)===id);if(!order)return json(res,404,{error:'Order not found'});
    const current=order.payment_status,settings=await getSettings(),field='stock_'+order.duration,qty=Number(order.quantity);
    if(current!=='Paid'&&status==='Paid'){if(settings[field]<qty)return json(res,409,{error:'Not enough stock to mark this order paid'});settings[field]-=qty;await setSettings(settings)}
    if(current==='Paid'&&status!=='Paid'){settings[field]+=qty;await setSettings(settings)}
    await setOrderStatus(id,status);return json(res,200,{ok:true});
  }
  if(method==='POST'&&url.pathname==='/api/admin/keys'){
    if(!requireAdmin(req,res,true))return;const b=await readBody(req),duration=String(b.duration||''),quantity=Number(b.quantity);if(!validDuration(duration)||!validQuantity(quantity))return json(res,400,{error:'Invalid key configuration'});
    const chunk=()=>crypto.randomBytes(3).toString('hex').slice(0,4).toUpperCase(),item={boost_key:`BKT-${chunk()}-${chunk()}-${chunk()}`,duration,quantity,key_status:'Active',created_at:new Date().toISOString(),redeemed_at:null};await addKey(item);return json(res,201,{ok:true,key:item});
  }
  return json(res,404,{error:'Not found'});
}
const indexFile=path.join(__dirname,'index.html');
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,'http://localhost');
    if(url.pathname.startsWith('/api/'))return await api(req,res,url);
    if(url.pathname==='/favicon.ico'){res.statusCode=204;return res.end()}
    if((req.method==='GET'||req.method==='HEAD')&&(url.pathname==='/'||url.pathname==='/index.html')){securityHeaders(res,'text/html; charset=utf-8');res.setHeader('Cache-Control','no-cache');if(req.method==='HEAD')return res.end();return fs.createReadStream(indexFile).pipe(res)}
    securityHeaders(res,'text/plain; charset=utf-8');res.statusCode=404;res.end('Not found');
  }catch(err){if(!res.headersSent)json(res,err.message==='too-large'?413:400,{error:err.message==='invalid-json'?'Invalid request':err.message==='too-large'?'Request too large':'Request failed'});else res.end()}
});
initStorage().then(()=>server.listen(PORT,'0.0.0.0',()=>console.log(`Buckity server listening on ${PORT}`))).catch(err=>{console.error('Startup failed');process.exit(1)});
